<?php
defined('_JEXEC') or die();
/**
 * Downlodable media plugin for Product
 *
 * @version $Id:
 * @package VirtueMart
 * @subpackage Plugins - istraxx_download_simple
 * @author Max Milbers
 * @copyright Copyright (C) 2012-2018 iStraxx - All rights reserved.
 * @license LGPLv3
 *
 */

$aveDayPerM = 30.4;

	?><h3><?php echo $viewData[0]->media->file_description ?></h3><div><?php echo $viewData[0]->media->file_title ?></div><?php
